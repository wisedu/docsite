<template>
  <div>
    <router-view></router-view>
  </div>
</template>
<script>
	// import 'bh-mint-ui/lib/spinner/style.css';
    import style from './style.css'
    import 'mint-ui/lib/style.css'
    export default {
        data () {
            return {}
        }
    }
</script>